package com.example.guia33;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    CheckBox c1, c2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        c1 = (CheckBox) findViewById(R.id.idCheck1);
        c2 = (CheckBox) findViewById(R.id.idCheck2);
    }

    public void onClick(View view) {

        if (view.getId() == R.id.btn1){
            validar();
        }
    }

    private void validar(){
        String cadena = "Seleccionado:";

        if (c1.isChecked()){
            cadena += " Opcion1";
        }

        if (c2.isChecked()){
            cadena += " Opcion2";
        }

        Toast.makeText(getApplicationContext(), cadena, Toast.LENGTH_SHORT).show();

    }
}