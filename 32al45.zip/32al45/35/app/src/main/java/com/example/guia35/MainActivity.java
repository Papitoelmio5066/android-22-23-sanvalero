package com.example.guia35;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    ToggleButton tgBtn;
    TextView eti2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tgBtn = (ToggleButton) findViewById(R.id.tgBtn1);
        eti2 = (TextView) findViewById(R.id.eti2);
    }

    public void onClick(View view) {
        if (view.getId() == R.id.tgBtn1) {
            if (tgBtn.isChecked()) {
                eti2.setText("Boton ON");
            } else {
                eti2.setText("Boton OFF");
            }
        }
    }

}