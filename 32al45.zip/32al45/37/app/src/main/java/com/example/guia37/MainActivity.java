package com.example.guia37;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "Seguimiento";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.i("Info", "Valor informacion");
        Log.d("Debug", "Valor debug");
        Log.w("Warning", "Valor warning");
        Log.e("Error", "Valor error");
        Log.v("Verbose", "Valor verbose");

        Log.i(TAG, "Mensaje seguimiento 1");
        Log.i(TAG, "Mensaje seguimiento 2");
        Log.i(TAG, "Mensaje seguimiento 3");
        Log.i(TAG, "Mensaje seguimiento 4");
        Log.i(TAG, "Mensaje seguimiento 5");
    }
}