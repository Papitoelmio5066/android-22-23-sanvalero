package com.example.guia36;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView eti2;
    Switch switchE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eti2 = (TextView) findViewById(R.id.eti2);
        switchE = (Switch) findViewById(R.id.idSwitch);
    }


    public void onClick(View view) {
        if(view.getId() == R.id.idSwitch){
            if(switchE.isChecked()){
                eti2.setText("Activado");
            } else {
                eti2.setText("Desactivdo");
            }
        }
    }
}