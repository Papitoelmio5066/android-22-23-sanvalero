package com.example.guia33;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioButton r1, r2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        r1 = (RadioButton) findViewById(R.id.idRadio1);
        r2 = (RadioButton) findViewById(R.id.idRadio2);
    }

    public void onClick(View view) {

        if (view.getId() == R.id.btn1){
            validar();
        }
    }

    private void validar(){
        String cadena = "Seleccionado:";

        if (r1.isChecked()){
            cadena += " Opcion1";
        }

        if (r2.isChecked()){
            cadena += " Opcion2";
        }

        Toast.makeText(getApplicationContext(), cadena, Toast.LENGTH_SHORT).show();

    }
}