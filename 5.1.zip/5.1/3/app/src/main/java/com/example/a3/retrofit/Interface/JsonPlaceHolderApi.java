package com.example.a3.retrofit.Interface;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;


import com.example.a3.retrofit.model.Posts;



public interface JsonPlaceHolderApi {

    @GET("posts")
    Call<List<Posts>> getPosts();

}
