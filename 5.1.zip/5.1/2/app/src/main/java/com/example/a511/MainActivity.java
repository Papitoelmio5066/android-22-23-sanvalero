package com.example.a511;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<PersonajeVo> listPersonajes;
    RecyclerView recyclerPersonajes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listPersonajes = new ArrayList<PersonajeVo>();

        recyclerPersonajes = (RecyclerView) findViewById(R.id.recyclerId);
        recyclerPersonajes.setLayoutManager(new LinearLayoutManager(this));

        llenarPersonajes();
        
        AdaptadorPersonajes adapter = new AdaptadorPersonajes(listPersonajes);
        recyclerPersonajes.setAdapter(adapter);
    }

    private void llenarPersonajes() {
        // No tengo las imagenes descargadas ni las info copiadas
        listPersonajes.add(new PersonajeVo("Krusty","Payaso", R.drawable.ic_launcher_background ));
        listPersonajes.add(new PersonajeVo("Homer","Padre", R.drawable.ic_launcher_background ));
        listPersonajes.add(new PersonajeVo("Marge","Madre", R.drawable.ic_launcher_background ));
        listPersonajes.add(new PersonajeVo("Bart","Hijo", R.drawable.ic_launcher_background ));

    }
}